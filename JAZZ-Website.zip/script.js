const menuToggle=document.getElementById('menuToggle');
const nav=document.getElementById('nav');
menuToggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuToggle.setAttribute('aria-expanded',String(open));});
document.getElementById('themeToggle').addEventListener('click',()=>{document.body.classList.toggle('light');});
document.getElementById('contactForm').addEventListener('submit',event=>{event.preventDefault();document.getElementById('formNotice').textContent='Thanks! This demo form is ready to be connected to an email service.';event.target.reset();});
